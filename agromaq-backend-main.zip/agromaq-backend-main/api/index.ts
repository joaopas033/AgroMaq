import { NestFactory } from '@nestjs/core'
import { ExpressAdapter } from '@nestjs/platform-express'
import { AppModule } from '../src/app.module'
import * as express from 'express'

const server = express()

let cachedApp: any = null

async function createApp() {
  if (!cachedApp) {
    const expressAdapter = new ExpressAdapter(server)
    const app = await NestFactory.create(AppModule, expressAdapter)
    
    // Habilitar CORS para o frontend
    app.enableCors({
      origin: [
        'http://localhost:3000', 
        'http://localhost:3001',
        'https://agromaq-front.vercel.app',
        /\.vercel\.app$/ // Permite todos os preview deployments da Vercel
      ],
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'Accept'],
      credentials: true,
    })

    // Prefixo global para todas as rotas
    app.setGlobalPrefix('api')

    await app.init()
    cachedApp = app
  }
  
  return cachedApp
}

export default async (req: any, res: any) => {
  await createApp()
  server(req, res)
}

